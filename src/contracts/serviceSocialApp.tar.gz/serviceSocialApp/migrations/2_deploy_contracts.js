var socialService = artifacts.require(./socialService);

module.exports = async function(deployer, network, accounts) {
  let socialserviceInstanceFuture = socialService.new(['si', 'no', 'Marta']);
  let socialserviceInstance = await socialserviceInstanceFuture;
  console.log(socialserviceInstance.address);
};
