// Import the page's CSS. Webpack will know what to do with it.
import "../stylesheets/app.css";

// Import libraries we need.
import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'

// Import our contract artifacts and turn them into usable abstractions.
import socialservice_artifacts from '../../build/contracts/socialService.json'
// Voting is our usable abstraction, which we'll use through the code below.
var socialService = contract(socialservice_artifacts);

// In your nodejs console, execute contractInstance.address to get the address at which the contract is deployed and change the line below to use your deployed address
var contractInstance = socialService.at('0x658146f01a63e1cd179a3dae99afd6e4007af51a');
var  opts = {"si": "option-1", "no": "option-2", "Marta": "option-3"};

window.App = {
    start: function() {
      var self = this;

      socialService.setProvider(web3.currentProvider);
      socialService.defaults({from: web3.eth.coinbase});

      web3.eth.getAccounts(function(err, accs) {
        if (err != null) {
          alert("there was an error fetching your accoutns.");
          return;
        }
        if (accs.length == 0) {
          alert("No accounts");
          return;
        }
      });

      var selecOpts = Object.keys(opts);
      for (var i = 0; i < selecOpts.length; i++) {
        let selecOpt = selecOpts[i];

        //self.refreshOpt(selecOpt);
      }

    },

    confirmService: async function(message) {
      var selecOpt = $("#opt").val();
      var address = web3.eth.coinbase;
      var approved = await contractInstance.confirmService(selecOpt, {from: address});
      alert(approved);
      location.reload();

      //self.refreshCandidate(candidateName);
    }
};


window.addEventListener('load', function(){
  if (typeof web3 !== 'undefined') {
    //console.warn("Using web3 detected from external source. If you find that your accounts don't appear, ensure you've configured that source properly. If using MetaMask, see the following link. Feel free to delete this warning. :) http://truffleframework.com/tutorials/truffle-and-metamask");
    // Use Mist/MetaMask's provider
    window.web3 = new Web3(web3.currentProvider);
  } else {
    console.warn("No web3 detected. Falling back to http://localhost:8545. You should remove this fallback when you deploy live, as it's inherently insecure. Consider switching to Metamask for development. More info here: http://truffleframework.com/tutorials/truffle-and-metamask");
    // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
    window.web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
  }

  App.start();
});
